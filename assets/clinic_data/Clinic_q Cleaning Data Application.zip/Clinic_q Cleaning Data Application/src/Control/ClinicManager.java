package Control;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import com.google.gson.*;

import Entity.Clinic;


public class ClinicManager {
	private ArrayList<Clinic> clinicAl;
	
	public ClinicManager() {
		try {
			clinicAl = TextDB.readClinic("C:\\Users\\Admin\\Desktop\\chas-clinics-kml.kml");
			Gson gson = new GsonBuilder().setPrettyPrinting().create();
			String gsonStr = gson.toJson(clinicAl);
			System.out.println("hello" + gsonStr);  
			BufferedWriter writer = new BufferedWriter(new FileWriter("C:\\Users\\Admin\\Desktop\\ClinicData.json", false));
		    writer.append(gsonStr);
		    writer.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public void printClinicAl() {
		for (Clinic c : clinicAl) {
			System.out.println(c.toString());
		}
		System.out.println("Total AL length = " + clinicAl.size());
	}
	
	public void findClinic(String clinicName) {
		for (Clinic c : clinicAl) {
			if (c.getClinicName().equalsIgnoreCase(clinicName)) {
				System.out.println("Found Clinic!\n" + c.toString());
				return;
			}
		}
	}
}
